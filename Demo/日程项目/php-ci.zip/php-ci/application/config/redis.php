<?php

$config['redis_ip'] = '';
$config['redis_passwd'] = '';
$config['redis_port'] = '';


