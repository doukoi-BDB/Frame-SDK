// export const BAES_URL = "http://api-java.bdb-888.cn/web/api/";
// #ifdef APP
export const BAES_URL = "https://xxx.com/Main/action/";
// #endif
// #ifdef H5
export const BAES_URL = "/api/";
// #endif



//请求路径
export const service = {
	region: "Other/Schedule/region",
	login: "Other/Schedule/login",
	getUserInfo: "Other/Schedule/getUser",
	updateUserInfo: "Other/Schedule/update",
	
	sendContent: "Other/Schedule/sendContent",
	delContent: "Other/Schedule/delContent",
	getContent: "Other/Schedule/getContent",
	
	notice:"Other/Schedule/notice",
	
	insertText:"Other/Schedule/insertText",
	getTextList:"Other/Schedule/getTextList",
	delText:"Other/Schedule/delText",
}